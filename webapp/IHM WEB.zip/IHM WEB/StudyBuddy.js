// TRANSITION DU HEADER

let ticking = false;

function updateHeader() {
    const header = document.querySelector('header');
    const banner = document.querySelector('.banner');
    const bannerBottom = banner.offsetTop + banner.offsetHeight;
    
    if (window.scrollY > bannerBottom - 80) {
        header.classList.add('scrolled');
    } else {
        header.classList.remove('scrolled');
    }
    ticking = false;
}

function onScroll() {
    if (!ticking) {
        requestAnimationFrame(updateHeader);
        ticking = true;
    }
}

window.addEventListener('scroll', onScroll, { passive: true });

// SLIDE HEADER AUTOMATIQUE

document.addEventListener('DOMContentLoaded', function() {
    let currentSlide = 0;
    const slides = document.querySelectorAll('.carousel-slide');
    const totalSlides = slides.length;
    
    if (totalSlides > 0) {
        function showNextSlide() {
            slides[currentSlide].classList.remove('active');
            currentSlide = (currentSlide + 1) % totalSlides;
            slides[currentSlide].classList.add('active');
        }
        
        setInterval(showNextSlide, 4000);
    }
});

// ANIMATION SCROLL POUR LES BLOCS

document.addEventListener('DOMContentLoaded', function() {
    const blocksToReveal = document.querySelectorAll('.session-status-block, .lofi-music-block, .work-environment-block, .today-sessions-block, .study-time-block, .consecutive-days-block, .avg-focus-block, .graph-block, .add-homework-block, .add-exam-block, .upcoming-tasks-block, .calendar-block');
    
    function isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top <= (window.innerHeight || document.documentElement.clientHeight) * 0.85 &&
            rect.bottom >= 0
        );
    }
    
    function revealVisibleBlocks() {
        blocksToReveal.forEach(block => {
            if (isElementInViewport(block)) {
                block.classList.add('visible');
                block.classList.remove('hidden');
            }
        });
    }
    
    revealVisibleBlocks();
    let scrollTicking = false;
    
    function onScrollReveal() {
        if (!scrollTicking) {
            requestAnimationFrame(() => {
                revealVisibleBlocks();
                scrollTicking = false;
            });
            scrollTicking = true;
        }
    }
    
    window.addEventListener('scroll', onScrollReveal, { passive: true });
    window.addEventListener('resize', revealVisibleBlocks, { passive: true });
});

// POMPODORO TIMER : start

document.addEventListener('DOMContentLoaded', function() {
    const timerDisplay = document.getElementById('timer');
    const phaseDisplay = document.getElementById('phase');
    const startBtn = document.getElementById('startBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const resetBtn = document.getElementById('resetBtn');
    const modeButtons = document.querySelectorAll('.mode-btn');
    
    let isRunning = false;
    let isPaused = false;
    let timeLeft = 25 * 60;
    let timerInterval = null;
    let currentPhase = 'work';
    let currentMode = 'classic';
    
    const config = {
        classic: { work: 25 * 60, break: 5 * 60 },
        long: { work: 50 * 60, break: 10 * 60 }
    };

    updateDisplay();
    startBtn.addEventListener('click', toggleTimer);
    pauseBtn.addEventListener('click', pauseTimer);
    resetBtn.addEventListener('click', resetTimer);
    
    modeButtons.forEach(btn => {
        btn.addEventListener('click', function() {
            const mode = this.dataset.mode;
            switchMode(mode);
        });
    });
    




    
    function switchMode(mode) {
        if (currentMode === mode) return;
        
        currentMode = mode;
        
        modeButtons.forEach(btn => {
            if (btn.dataset.mode === currentMode) {
                btn.classList.add('active');
            } else {
                btn.classList.remove('active');
            }
        });
        
        resetTimer();
    }
    
    function toggleTimer() {
        if (!isRunning) {
            startTimer();
        } else if (isPaused) {
            resumeTimer();
        } else {
            pauseTimer();
        }
    }
    
    function startTimer() {
        if (isRunning) return;
        
        isRunning = true;
        isPaused = false;
        
        startBtn.innerHTML = '<span class="btn-icon">⏸</span><span class="btn-text">Pause</span>';
        pauseBtn.disabled = true;
        
        startTimerInterval();
    }
    
    function startTimerInterval() {
        clearInterval(timerInterval);
        
        timerInterval = setInterval(() => {
            if (timeLeft <= 0) {
                switchPhase();
                return;
            }
            
            timeLeft--;
            updateDisplay();
        }, 1000);
    }
    
    function pauseTimer() {
        if (!isRunning || isPaused) return;
        
        isPaused = true;
        clearInterval(timerInterval);
        
        startBtn.innerHTML = '<span class="btn-icon">▶</span><span class="btn-text">Reprendre</span>';
        pauseBtn.disabled = false;
    }
    
    function resumeTimer() {
        if (!isRunning || !isPaused) return;
        
        isPaused = false;
        startTimerInterval();
        
        startBtn.innerHTML = '<span class="btn-icon">⏸</span><span class="btn-text">Pause</span>';
        pauseBtn.disabled = true;
    }
    
    function resetTimer() {
        isRunning = false;
        isPaused = false;
        clearInterval(timerInterval);
        
        currentPhase = 'work';
        timeLeft = config[currentMode].work;
        
        startBtn.innerHTML = '<span class="btn-icon">▶</span><span class="btn-text">Démarrer</span>';
        pauseBtn.disabled = true;
        
        updateDisplay();
        updatePhaseDisplay();
    }
    
    function switchPhase() {
        clearInterval(timerInterval);
        
        if (currentPhase === 'work') {
            currentPhase = 'break';
        } else {
            currentPhase = 'work';
        }
        
        timeLeft = config[currentMode][currentPhase];
        
        updateDisplay();
        updatePhaseDisplay();
        
        if (isRunning) {
            startTimerInterval();
        }
    }
    
    function updateDisplay() {
        const minutes = Math.floor(timeLeft / 60);
        const seconds = timeLeft % 60;
        timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
    }
    
    function updatePhaseDisplay() {
        const phaseText = currentPhase === 'work' ? 'TRAVAIL' : 'PAUSE';
        phaseDisplay.textContent = phaseText;
    }
});